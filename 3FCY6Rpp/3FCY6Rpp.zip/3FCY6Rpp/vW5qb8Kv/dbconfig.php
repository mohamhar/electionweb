<?php
$server="localhost";
$serverlogin="dbPHP";
$pswd="dHtGStaUBZaCdqYnJcYPnTpb9Cc77yPe";
$dbname="electionweb";
$table="volunteers";
$table2="listcall";
$table3="walklist";
$table4="requests";
$table5="list";
$demo="demo";

?>