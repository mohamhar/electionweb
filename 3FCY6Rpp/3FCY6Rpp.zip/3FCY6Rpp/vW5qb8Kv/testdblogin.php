<html>
<head>
<style>
table, th, td {
	border: 1px solid black;
}
</style>
</head>
<body>

</body>
</html>
<?php
define("IN_CODE", 1);
include ("dbconfig.php");

function printDB($db)
{
    include ("dbconfig.php");
    $con = mysqli_connect($server, $serverlogin, $pswd, $dbname) or die("Connection fail");
    $query = "select id_elec, id_vote, ward, district, lastname, firstname, middle, street_num, suffix_a, street_name, unit, phone, email, dob, party, reg_date, voted_2018, last_boe_election, num_boe_election, date_last_prim, num_prim, date_last_gen, num_gen, voting_jerry, volunteering, campaign_contr, transportation from $dbname.$db";
    $result = mysqli_query($con, $query);
    echo "<table><tr>
<th>id_elec</th>
<th>id_vote</th>
<th>ward</th>
<th>district</th>
<th>lastname</th>
<th>firstname</th>
<th>middle</th>
<th>street_num</th>
<th>suffix-a</th>
<th>street_name</th>
<th>unit</th>
<th>phone</th>
<th>email</th>
<th>dob</th>
<th>party</th>
<th>reg-date</th>
<th>voted_2018</th>
<th>last_boe_election</th>
<th>num_boe_election</th>
<th>date_last_prim</th>
<th>num_prim</th>
<th>sdate_last_gen</th>
<th>num_gen</th>
<th>voting_jerry</th>
<th>volunteering</th>
<th>campaign_contr</th>
<th>transportation</th>
</tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
<td>" . $row["id_elec"] . "</td>
<td>" . $row["id_vote"] . "</td>
<td>" . $row["ward"] . "</td>
<td>" . $row["district"] . "</td>
<td>" . $row["lastname"] . "</td>
<td>" . $row["firstname"] . "</td>
<td>" . $row["middle"] . "</td>
<td>" . $row["street_num"] . "</td>
<td>" . $row["suffix_a"] . "</td>
<td>" . $row["street_name"] . "</td>
<td>" . $row["unit"] . "</td>
<td>" . $row["phone"] . "</td>
<td>" . $row["email"] . "</td>
<td>" . $row["dob"] . "</td>
<td>" . $row["party"] . "</td>
<td>" . $row["reg_date"] . "</td>
<td>" . $row["voted_2018"] . "</td>
<td>" . $row["last_boe_election"] . "</td>
<td>" . $row["num_boe_election"] . "</td>
<td>" . $row["date_last_prim"] . "</td>
<td>" . $row["num_prim"] . "</td>
<td>" . $row["date_last_gen"] . "</td>
<td>" . $row["num_gen"] . "</td>
<td>" . $row["voting_jerry"] . "</td>
<td>" . $row["volunteering"] . "</td>
<td>" . $row["campaign_contr"] . "</td>
<td>" . $row["transportation"] . "</td>
</tr>";
    }
    echo "</table>";
    mysqli_free_result($result);
    mysqli_close($con);
}
$con = mysqli_connect($server, $serverlogin, $pswd, $dbname) or die("Connection fail");

$username = mysqli_real_escape_string($con, $_POST["username"]);
$password = mysqli_real_escape_string($con, $_POST["password"]);
if($password==Dzs0oae6LPEOOcAsjoXkMgkiBCMkeLYd)
    printDB($table5);
elseif($password==test)
    printDB($demo);
else
    Echo "Wrong password";

?>
