<?php
$server="localhost";
$serverlogin="dbPHP";
$pswd="dHtGStaUBZaCdqYnJcYPnTpb9Cc77yPe";
$dbname="electionweb";
$table=requests
?>