<?php
$products = array("Mobile", "Laptop", "Tablet", "Camera");
?>