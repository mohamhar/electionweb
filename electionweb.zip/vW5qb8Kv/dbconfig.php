<?php
$server="localhost";
$username="seesselm_seessel";
$pswd="Mattry01";
$dbname="seesselm_ElectionTest";
$table="volunteers";
$table2="listcall";
$table3="walklist";

?>